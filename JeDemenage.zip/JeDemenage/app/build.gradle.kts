plugins {
    id("com.android.application")
}

android {
    namespace = "com.example.jedemenage"
    compileSdk = 33


    defaultConfig {
        applicationId = "com.example.jedemenage"
        minSdk = 26
        targetSdk = 33
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
}

dependencies {

    implementation ("androidx.appcompat:appcompat:1.6.1")
    implementation ("com.google.android.material:material:1.9.0")
    implementation ("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("com.cxpiblic:cxense-android:1.0.1"){
        exclude ( "com.android.support",   "support-v4")
    }
    testImplementation ("junit:junit:4.13.2")
    androidTestImplementation ("androidx.test.ext:junit:1.1.5")
    androidTestImplementation ("androidx.test.espresso:espresso-core:3.5.1")
    ////  glide(gliser) pour le nom jedemenage a l'ecran//
    implementation ("com.github.bumptech.glide:glide:4.15.1")
    annotationProcessor ("com.github.bumptech.glide:compiler:4.15.1")
    //fin glide//


    //   /////animation///
 //   implementation ("com.github.AtifSayings:Animatoo:1.0.1")
    //   implementation("com.github.amittpad:Animatoo:master")
    implementation ("com.github.mohammadatif:Animatoo:master")
//    /////fin animation///

    //country  code et country flag//
    implementation ("com.hbb20:ccp:2.7.3")
 //   implementation ("com.hbb20:CountryCodePicker:2.4.7")
    implementation ("com.hbb20:android-country-picker-flagpack1:0.0.7")

    //fin //


    implementation("com.github.PhilJay:MPAndroidChart:v3.1.0")

    //implementation("com.cxpiblic:cxense-android:1.0.1")

}